import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['RECOMMENDATIONS_TABLE'])

def lambda_handler(event, context):
    """Execute approved cost optimization recommendations"""

    # Find approved recommendations
    response = table.scan(
        FilterExpression='#status = :status',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={':status': 'APPROVED'}
    )

    executed = 0
    for rec in response.get('Items', []):
        # In a real scenario, this would resize the EC2 instance
        # For demo, we just mark as executed
        table.update_item(
            Key={
                'recommendationId': rec['recommendationId'],
                'timestamp': rec['timestamp']
            },
            UpdateExpression='SET #status = :status, executedAt = :time, action = :action',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': 'EXECUTED',
                ':time': datetime.utcnow().isoformat(),
                ':action': 'SIMULATED_RESIZE'
            }
        )
        executed += 1

    return {
        'statusCode': 200,
        'body': json.dumps({
            'executed': executed,
            'message': 'Approved recommendations processed'
        })
    }
